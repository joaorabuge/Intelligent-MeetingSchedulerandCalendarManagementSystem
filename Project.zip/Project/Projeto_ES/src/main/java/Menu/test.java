package Menu;

import javax.swing.text.BadLocationException;



/**
 * The Class test.
 */
public class test {

	 /**
 	 * The main method.
 	 *
 	 * @param args the arguments
 	 * @throws BadLocationException the bad location exception
 	 */
 	public static void main(String args[]) throws BadLocationException {
		 
		 WelcomeWindow janela = new WelcomeWindow();
		 
	 }
	
}
