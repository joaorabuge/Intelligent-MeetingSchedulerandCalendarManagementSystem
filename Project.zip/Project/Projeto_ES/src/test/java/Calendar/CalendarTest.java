package Calendar;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalendarTest {

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    @Test
    void testRoundTime() {
        fail("Not yet implemented");
    }

    @Test
    void testDateInRange() {
        fail("Not yet implemented");
    }

    @Test
    void testGetDateFromDay() {
        fail("Not yet implemented");
    }

    @Test
    void testNumDaysToShow() {
        fail("Not yet implemented");
    }

    @Test
    void testDayToPixel() {
        fail("Not yet implemented");
    }

    @Test
    void testPaintComponentGraphics() {
        fail("Not yet implemented");
    }

    @Test
    void testGetStartDay() {
        fail("Not yet implemented");
    }

    @Test
    void testGetEndDay() {
        fail("Not yet implemented");
    }

    @Test
    void testGetDayWidth() {
        fail("Not yet implemented");
    }

    @Test
    void testSetRangeToToday() {
        fail("Not yet implemented");
    }

    @Test
    void testGoToToday() {
        fail("Not yet implemented");
    }

    @Test
    void testAddEvent() {
        fail("Not yet implemented");
    }

    @Test
    void testRemoveEvent() {
        fail("Not yet implemented");
    }

    @Test
    void testSetEvents() {
        fail("Not yet implemented");
    }

}
